package com.mmstechnology.dmw.api_eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
