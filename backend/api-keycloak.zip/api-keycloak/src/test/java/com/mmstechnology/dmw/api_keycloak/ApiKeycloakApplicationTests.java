package com.mmstechnology.dmw.api_keycloak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiKeycloakApplicationTests {

	@Test
	void contextLoads() {
	}

}
